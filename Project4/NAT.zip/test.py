import array
import socket
import struct
import time

def inCksum(packet):
    if len(packet) & 1:
        packet = packet + '\0'
    words = array.array('h', packet)
    sum = 0
    for word in words:
        sum += (word & 0xffff)
    sum = (sum >> 16) + (sum & 0xffff)
    sum = sum + (sum >> 16)
    return (~sum) & 0xffff

header = struct.pack('bbHHh', 8, 0, 0, 12345, 0)
data = struct.pack('d', time.time())
packet = header + data
chkSum = inCksum(packet)
header = struct.pack('bbHHh', 8, 0, chkSum, 12345, 0)
icmp_data = header + data

Sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.getprotobyname('icmp'))
Sock.settimeout(1)
start = time.time()
Sock.sendto(icmp_data, ("127.0.0.1", 0))

recv_packet, addr = Sock.recvfrom(1024)
end = time.time()
type, code, checkSum, packe_ID, sequence = struct.unpack("bbHHh", recv_packet[20:28])


print("Header : ", type, code, checkSum, packe_ID, sequence)
print("Time : ", end - start)