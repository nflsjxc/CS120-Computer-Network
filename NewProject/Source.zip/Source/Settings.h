#pragma once

// Constant
#define PI (3.1415926)

//Mac frame
#define TYPE_ACK 0
#define TYPE_DATA 1
#define TYPE_MACPING_REQUEST 2
#define TYPE_MACPING_REPLY 3
#define TYPE_ICMP_REQUEST 4

#define NO_HEADER -1
#define SYNC 0
#define DATA_PROCESS 1
#define DATA_RECEIVED 2

#define FRAME_OFFSET 32
#define CRC_LEN 8
#define IP_PORT_LEN 48

//Phy frame
#define AUDIO_BUFFER_SIZE (1000) // Allow 1000 frames waiting
#define HEADER_LEN (60)
#define POWER_THRES (15)
//  60 Header + 3(sample)*144(bit) data + 20zero =512 samples per frame


#define DEFAULT_RWS 4
#define MAX_WAITING_TIME 1500
#define MAX_RESEND_TIME 10
