#pragma once
#include<queue>
using namespace std;

const int MAX_SIZE = 1000000;

class Buffer
{
public:
	Buffer() {  }
	~Buffer() {  }
	bool isempty() { return q.empty(); }
	int getsize() { return q.size(); }
	float get()
	{
		if (!isempty())
		{
			return q.front();
		}
		else return 0;
	}
	bool isfull() { return q.size() >= MAX_SIZE; }
	bool push(float x)
	{
		if (!isfull())
		{
			q.push(x);
			return true;
		}
		return false;
	}
	bool pop()
	{
		if (!isempty())
		{
			q.pop();
			return true;
		}
		return false;
	}

	bool write(float* data, int len)
	{
		if (q.size() + len >= MAX_SIZE)return false;
		for (int i = 0; i < len; i++)
		{
			q.push(data[i]);
		}
		return true;
	}
private:
	queue<float> q;
};